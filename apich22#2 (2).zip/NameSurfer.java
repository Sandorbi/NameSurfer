
/*
 * File: NameSurfer.java
 * ---------------------
 * When it is finished, this program will implements the viewer for
 * the baby-name database described in the assignment handout.
 */

import acm.program.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;

public class NameSurfer extends Program implements NameSurferConstants {

	/* Method: init() */
	/**
	 * This method has the responsibility for reading in the data base and
	 * initializing the interactors at the bottom of the window.
	 */

	public void init() {
		graphObj = new NameSurferGraph();
		add(graphObj);

		createDataObject();

		createInteractors();

		addInteractors();

		actionListeners();
	}

	// Creates interactors needed for the program.
	private void createInteractors() {
		text = new JTextField(15);
		graph = new JButton("Graph");
		clear = new JButton("Clear");
	}

	// Adds interactors on display.
	private void addInteractors() {
		add(new JLabel("Name"), SOUTH);
		add(text, SOUTH);
		add(graph, SOUTH);
		add(clear, SOUTH);
	}

	// Adds actionListener of interactors.
	private void actionListeners() {
		graph.addActionListener(this);
		clear.addActionListener(this);
		text.addActionListener(this);

	}

	// Create object of NameSurferDataBase.
	private void createDataObject() {
		try {
			data = new NameSurferDataBase(NAMES_DATA_FILE);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	/* Method: actionPerformed(e) */
	/**
	 * This class is responsible for detecting when the buttons are clicked.
	 */
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == text || e.getSource() == graph) {
			if (!text.getText().isEmpty()) {
				String givenName = convertName();
				if (data != null) {
					if (data.findEntry(givenName) != null) {
						graphObj.addEntry(data.findEntry(givenName));
					}
				}
				text.setText("");
			}
		}
		if (e.getSource() == clear) {
			graphObj.clear();
		}
	}

	// Converts given name to form that is given in name-data.txt file.
	private String convertName() {
		String name = text.getText().substring(0, 1).toUpperCase() + text.getText().substring(1).toLowerCase();
		return name;
	}

	private NameSurferDataBase data;
	private NameSurferGraph graphObj;
	private JTextField text;
	private JButton graph;
	private JButton clear;

}
