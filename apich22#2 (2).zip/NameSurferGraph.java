
/*
 * File: NameSurferGraph.java
 * ---------------------------
 * This class represents the canvas on which the graph of
 * names is drawn. This class is responsible for updating
 * (redrawing) the graphs whenever the list of entries changes or the window is resized.
 */

import acm.graphics.*;
import acm.util.RandomGenerator;

import java.awt.event.*;
import java.util.*;
import java.awt.*;

public class NameSurferGraph extends GCanvas implements NameSurferConstants, ComponentListener {

	private ArrayList<NameSurferEntry> entryStorage = new ArrayList<NameSurferEntry>();
	private HashMap<String, Color> colorStorage = new HashMap<String, Color>();
	private RandomGenerator rgen = new RandomGenerator();

	/**
	 * Creates a new NameSurferGraph object that displays the data.
	 */
	public NameSurferGraph() {
		addComponentListener(this);
	}

	/**
	 * Clears the list of name surfer entries stored inside this class and
	 * clears colorStorage.
	 */
	public void clear() {
		entryStorage.clear();
		colorStorage.clear();
		update();
	}

	/* Method: addEntry(entry) */
	/**
	 * Adds a new NameSurferEntry to the list of entries on the display.
	 */
	public void addEntry(NameSurferEntry entry) {
		entryStorage.add(entry);
		update();
	}

	/**
	 * Updates the display image by deleting all the graphical objects from the
	 * canvas and then reassembling the display according to the list of
	 * entries.
	 */
	public void update() {
		removeAll();
		createBackGround();
	}

	// CreatesBackGround and draws graphs on display.
	private void createBackGround() {
		addVerticalLinesWithLabels();
		addHorizontalLines();
		drawGraphs();
	}

	// Adds vertical lines on canvas
	private void addVerticalLinesWithLabels() {
		for (int i = 0; i < NDECADES; i++) {
			GLine vertiLine = new GLine(i * (getWidth() / NDECADES), 0, i * (getWidth()) / NDECADES, getHeight());
			addLabels(vertiLine.getEndPoint(), i);
			add(vertiLine);
		}
	}

	// Adds labels of decades at the bottom of canvas.
	private void addLabels(GPoint endPoint, int i) {
		GLabel label = new GLabel("" + (1900 + i * 10), getWidth() / NDECADES, GRAPH_MARGIN_SIZE);
		add(label, endPoint);
	}

	// Adds horizontal lines on canvas.
	private void addHorizontalLines() {
		for (int i = 0; i < 2; i++) {
			GLine horiLine = new GLine(0, GRAPH_MARGIN_SIZE + i * (getHeight() - 2 * GRAPH_MARGIN_SIZE), getWidth(),
					GRAPH_MARGIN_SIZE + i * (getHeight() - 2 * GRAPH_MARGIN_SIZE));
			add(horiLine);
		}
	}

	// Draws graphs on canvas.
	private void drawGraphs() {
		for (int i = 0; i < entryStorage.size(); i++) {
			String name = entryStorage.get(i).getName();
			if (!colorStorage.containsKey(name)) {
				colorStorage.put(name, rgen.nextColor());
			}
			Color color = checkName(name);
			drawCorrespondingGraph(entryStorage.get(i), color);
		}
	}

	// Checks whether the given name already has color assigned or not.
	private Color checkName(String name) {
		if (colorStorage.containsKey(name)) {
			return colorStorage.get(name);
		} else {
			return rgen.nextColor();
		}
	}

	// Draws corresponding graph lines on canvas.
	private void drawCorrespondingGraph(NameSurferEntry entry, Color color) {
		int tableHeight = getHeight() - 2 * GRAPH_MARGIN_SIZE;
		double interval = (double) tableHeight / 1000;

		for (int decade = 0; decade < NDECADES - 1; decade++) {

			GPoint start = getStart(decade, interval, entry);

			GPoint end = getEnd(decade, interval, entry);

			addGraphLines(start, end, color);
			addGraphLabels(entry, decade, start, color);

		}
		addLastLabel(entry, interval, color);
	}

	// Finds Start point of graph in each decade.
	private GPoint getStart(int decade, double interval, NameSurferEntry entry) {
		GPoint start = new GPoint(decade * (getWidth() / NDECADES),
				GRAPH_MARGIN_SIZE + (interval * entry.getRank(START_DECADE + 10 * decade)));
		if (entry.getRank(START_DECADE + 10 * decade) == 0) {
			start = new GPoint(decade * (getWidth() / NDECADES), getHeight() - GRAPH_MARGIN_SIZE);
		}
		return start;
	}

	// Finds end point of graph in each decade.
	private GPoint getEnd(int decade, double interval, NameSurferEntry entry) {
		GPoint end = new GPoint((decade + 1) * (getWidth() / NDECADES),
				GRAPH_MARGIN_SIZE + (interval * entry.getRank(START_DECADE + 10 * (decade + 1))));

		if (entry.getRank(START_DECADE + 10 * (decade + 1)) == 0) {
			end = new GPoint((decade + 1) * (getWidth() / NDECADES), getHeight() - GRAPH_MARGIN_SIZE);
		}
		return end;
	}

	// Adds labels of graphs rank in each decade.
	private void addGraphLabels(NameSurferEntry entry, int decade, GPoint start, Color color) {
		GLabel entryLabel = new GLabel(entry.getName() + " " + entry.getRank(START_DECADE + 10 * decade), 20, 20);
		if (entry.getRank(START_DECADE + 10 * decade) == 0) {
			entryLabel.setLabel(entry.getName() + " *");
		}
		entryLabel.setColor(color);
		add(entryLabel, start);
	}

	// Adds graph lines.
	private void addGraphLines(GPoint start, GPoint end, Color color) {
		GLine line = new GLine(start.getX(), start.getY(), end.getX(), end.getY());
		line.setColor(color);
		add(line);

	}

	// Adds rank label of last decade for given entry.
	private void addLastLabel(NameSurferEntry entry, double interval, Color color) {
		GLabel entryLabel = new GLabel(entry.getName() + " " + entry.getRank(2000), 20, 20);
		if (entry.getRank(2000) != 0) {
			add(entryLabel, 10 * getWidth() / NDECADES, GRAPH_MARGIN_SIZE + (interval * entry.getRank(2000)));
		} else {
			add(entryLabel, 10 * getWidth() / NDECADES, getHeight() - GRAPH_MARGIN_SIZE);
			entryLabel.setLabel(entry.getName() + " *");
		}
		entryLabel.setColor(color);
	}

	/* Implementation of the ComponentListener interface */
	public void componentHidden(ComponentEvent e) {
	}

	public void componentMoved(ComponentEvent e) {
	}

	public void componentResized(ComponentEvent e) {
		update();
	}

	public void componentShown(ComponentEvent e) {
	}
}
